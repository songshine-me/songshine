#ifndef GONGJIJIN_H
#define GONGJIJIN_H

#include <QMainWindow>

namespace Ui {
class gongjijin;
}

class gongjijin : public QMainWindow
{
    Q_OBJECT

public:
    explicit gongjijin(QWidget *parent = nullptr);
    ~gongjijin();

private slots:
    void on_pushButton_xi_clicked();

    void on_pushButton_jin_clicked();

    void on_pushButton_exit_clicked();

private:
    Ui::gongjijin *ui;
};

#endif // GONGJIJIN_H
