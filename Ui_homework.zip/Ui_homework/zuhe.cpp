#include "zuhe.h"
#include "ui_zuhe.h"
#include <QString>
#include "math.h"
int leijia3(int n)
{
    int sum=0;
    for(int i=1; i<=n; i++)
        sum += i;
    return sum;
}
zuhe::zuhe(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::zuhe)
{
    ui->setupUi(this);
}

zuhe::~zuhe()
{
    delete ui;
}

void zuhe::on_pushButton_clicked()
{
    close();
}

void zuhe::on_pushButton_jin_clicked()
{
    QString temp;
    double jine1, jine2, time;
    double lilv1, lilv2, yuegong, zonge,lixi;
    temp = ui->lineEdit_jine_s->text();
    jine1 = temp.toDouble();
    temp = ui->lineEdit_time->text();
    time = temp.toDouble();
    temp = ui->lineEdit_lilv_s->text();
    lilv1 = temp.toDouble();
    temp = ui->lineEdit_jine_g->text();
    jine2 = temp.toDouble();
    temp = ui->lineEdit_lilv_g->text();
    lilv2 = temp.toDouble();
    yuegong = (jine1*100*(lilv1/12)*pow((1+lilv1/1200),time))/(pow((1+lilv1/1200),time)-1) + (jine2*100*(lilv2/12)*pow((1+lilv2/1200),time))/(pow((1+lilv2/1200),time)-1);
    zonge = yuegong * time;
    lixi = zonge - (jine1+jine2)*10000;
    ui->textEdit_result->setText("每月月供:"+QString::number(yuegong,10,2)+"\n"+"总还款金额:"+QString::number(zonge,10,2)+"\n"+"总利息："+QString::number(lixi,10,2));

}

void zuhe::on_pushButton_xi_clicked()
{
    QString temp;
    double jine1, jine2, time;
    double lilv1, lilv2, yuegong, zonge,lixi,chae;
    temp = ui->lineEdit_jine_s->text();
    jine1 = temp.toDouble();
    temp = ui->lineEdit_time->text();
    time = temp.toDouble();
    temp = ui->lineEdit_lilv_s->text();
    lilv1 = temp.toDouble();
    temp = ui->lineEdit_jine_g->text();
    jine2 = temp.toDouble();
    temp = ui->lineEdit_lilv_g->text();
    lilv2 = temp.toDouble();
    yuegong = jine1*10000/time + jine1*100*lilv1/12 + jine2*10000/time + jine2*100*lilv2/12;
    chae = jine1*(lilv1/12)*100/time + jine2*(lilv2/12)*100/time;
    zonge = yuegong*time - chae*leijia3(time-1);
    lixi = zonge - (jine1+jine2)*10000;
    ui->textEdit_result->setText("首月月供:"+QString::number(yuegong,10,2)+"\n"+"每月递减:"+QString::number(chae,10,2)+"\n"+"总还款金额:"+QString::number(zonge,10,2)+"\n"+"总利息："+QString::number(lixi,10,2));
}
