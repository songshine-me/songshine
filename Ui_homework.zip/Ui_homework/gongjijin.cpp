#include "gongjijin.h"
#include "ui_gongjijin.h"
#include <QString>
#include "math.h"
int leijia1(int n)
{
    int sum=0;
    for(int i=1; i<=n; i++)
        sum += i;
    return sum;
}
gongjijin::gongjijin(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::gongjijin)
{
    ui->setupUi(this);
}

gongjijin::~gongjijin()
{
    delete ui;
}

void gongjijin::on_pushButton_xi_clicked()
{
    QString temp;
    double jine, time;
    double lilv, yuegong, zonge,lixi;
    temp = ui->lineEdit_jine->text();
    jine = temp.toDouble();
    temp = ui->lineEdit_time->text();
    time = temp.toDouble();
    temp = ui->lineEdit_lilv->text();
    lilv = temp.toDouble();
    yuegong = (jine*100*(lilv/12)*pow((1+lilv/1200),time))/(pow((1+lilv/1200),time)-1);
    zonge = yuegong * time;
    lixi = zonge - jine*10000;
    ui->textEdit_result->setText("每月月供:"+QString::number(yuegong,10,2)+"\n"+"总还款金额:"+QString::number(zonge,10,2)+"\n"+"总利息："+QString::number(lixi,10,2));
}

void gongjijin::on_pushButton_jin_clicked()
{
    QString temp;
    double jine, time;
    double lilv, yuegong, zonge,lixi,chae;
    temp = ui->lineEdit_jine->text();
    jine = temp.toDouble();
    temp = ui->lineEdit_time->text();
    time = temp.toDouble();
    temp = ui->lineEdit_lilv->text();
    lilv = temp.toDouble();
    yuegong = jine*10000/time + jine*100*lilv/12;
    chae = jine*(lilv/12)*100/time;
    zonge = yuegong*time - chae*leijia1(time-1);
    lixi = zonge - jine*10000;
    ui->textEdit_result->setText("首月月供:"+QString::number(yuegong,10,2)+"\n"+"每月递减:"+QString::number(chae,10,2)+"\n"+"总金额:"+QString::number(zonge,10,2)+"\n"+"总利息："+QString::number(lixi,10,2));
}

void gongjijin::on_pushButton_exit_clicked()
{
    close();
}
