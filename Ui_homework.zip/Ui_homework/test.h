#ifndef TEST_H
#define TEST_H
#include "shangye.h"
#include "gongjijin.h"
#include "zuhe.h"
#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class Test; }
QT_END_NAMESPACE

class Test : public QMainWindow
{
    Q_OBJECT

public:
    Test(QWidget *parent = nullptr);
    ~Test();

private slots:
    void on_pushButton_S_clicked();

    void on_pushButton_G_clicked();

    void on_pushButton_Z_clicked();

    void on_pushButton_exit_clicked();

private:
    Ui::Test *ui;
    shangye *a;
    gongjijin *b;
    zuhe *c;
};

#endif // TEST_H
