#ifndef ZUHE_H
#define ZUHE_H

#include <QMainWindow>

namespace Ui {
class zuhe;
}

class zuhe : public QMainWindow
{
    Q_OBJECT

public:
    explicit zuhe(QWidget *parent = nullptr);
    ~zuhe();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_jin_clicked();

    void on_pushButton_xi_clicked();

private:
    Ui::zuhe *ui;
};

#endif // ZUHE_H
