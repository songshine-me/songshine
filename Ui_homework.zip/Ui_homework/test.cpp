#include "test.h"
#include "ui_test.h"

Test::Test(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Test)
{
    ui->setupUi(this);
}

Test::~Test()
{
    delete ui;
}


void Test::on_pushButton_S_clicked()
{
    a = new shangye;
    a->show();
}

void Test::on_pushButton_G_clicked()
{
    b = new gongjijin;
    b->show();
}

void Test::on_pushButton_Z_clicked()
{
    c = new zuhe;
    c->show();

}

void Test::on_pushButton_exit_clicked()
{
    close();
}
