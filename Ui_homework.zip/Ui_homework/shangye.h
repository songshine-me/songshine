#ifndef SHANGYE_H
#define SHANGYE_H

#include <QMainWindow>

namespace Ui {
class shangye;
}

class shangye : public QMainWindow
{
    Q_OBJECT

public:
    explicit shangye(QWidget *parent = nullptr);
    ~shangye();

private slots:
    void on_pushButton_jin_clicked();

    void on_pushButton_exit_clicked();

    void on_pushButton_xi_clicked();


private:
    Ui::shangye *ui;
};

#endif // SHANGYE_H
